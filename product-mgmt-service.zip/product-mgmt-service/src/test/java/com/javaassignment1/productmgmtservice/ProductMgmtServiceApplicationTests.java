package com.javaassignment1.productmgmtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMgmtServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
